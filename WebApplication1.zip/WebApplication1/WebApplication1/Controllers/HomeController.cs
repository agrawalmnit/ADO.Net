﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]

    [ApiController]
    public class HomeController : Controller
    {
        [HttpGet]
        [Route("getall")]
        public List<Person> Index() 
        {
            PersonDB db = new PersonDB();

            List<Person> obj = db.GetPersons();

            return obj;
        }
    }
}
